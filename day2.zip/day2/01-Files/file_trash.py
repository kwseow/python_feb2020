import send2trash
send2trash.send2trash("hello.txt")