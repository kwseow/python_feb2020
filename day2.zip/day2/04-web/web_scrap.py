#https://www.fortytwo.sg/dining/dining-tables/landon-regular-dining-table-coffee.html

import bs4
import requests

requestObj = requests.get("https://www.fortytwo.sg/dining/dining-tables/landon-regular-dining-table-coffee.html")
requestObj.raise_for_status()
soup = bs4.BeautifulSoup(requestObj.text, 'html.parser')
elements = soup.select("#product-price-46728")
print(elements[0].text)

